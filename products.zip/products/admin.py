from django.contrib import admin
from django.utils.html import format_html
from .models import Category,Subcategory,Product,ProductService,Maintenance_List,MaintenanceListPoint,Maintainencepoint,Warranty,Mileage,Year,SparePart,ServiceImage,History,Repairing,Vehicle,Maintenance,newSparePart,CheckMaintenance,CheckWarranty
from import_export import resources, fields
from adminsortable2.admin import SortableTabularInline
from adminsortable2.admin import SortableStackedInline
from django.contrib import admin
from django.urls import reverse
from django.db.models import Count
from import_export.widgets import DecimalWidget
from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .serializers import ProductSerializer,addServiceSerializer,MaintenanceListPointSerializer
from adminsortable2.admin import SortableAdminMixin
from django import forms
@admin.register(Maintainencepoint)
class MaintainencepointAdmin(admin.ModelAdmin):
    list_display = ('Point_id', 'Maintainencepoint_name', 'instructions', 'instruction_active', 'fill_active', 'value_active')
    list_filter = ( 'instruction_active', 'fill_active', 'value_active')
    search_fields = ('Maintainencepoint_name',)
    # class GalleryAdmin(admin.ModelAdmin):
    

# @admin.register(MaintenancePointOrder)
# class MaintenancePointOrderAdmin(admin.ModelAdmin):
#     list_display = ('maintenance_list_name', 'maintenance_point_name', 'order')


@admin.register(Maintenance_List)
class MaintenanceListAdmin(admin.ModelAdmin):
    
    list_display = ('Maintenance_list_id', 'Maintenance_list_name', 'Maintainence_description', 'display_maintenance_points','my_order')
    search_fields = ('Maintenance_list_name', 'Maintainence_description')
    # filter_vertical  = ('Maintenance_List_Point_name',)
    # ordering = ('my_order',)
    # raw_id_fields = ('Maintenance_List_Point_name',)
    # def __str__(self):
    #     return self.Maintenance_list_name
    def display_maintenance_points(self, obj):
        return ", ".join([point.Maintainencepoint_name for point in obj.Maintenance_List_Point_name.all()])
    display_maintenance_points.short_description = 'Maintenance Points'

    # def save(self, *args, **kwargs):
    #     # Call the parent class's save method
    #     super(Maintenance_List, self).save(*args, **kwargs)

    #     # Create a corresponding MaintenancePointOrder record
    #     MaintenancePointOrder.objects.create(
    #         maintenance_list_name=self.Maintenance_list_name,
    #         maintenance_point_name="Point Name",  # Replace with the actual point name
    #         order=1  # Replace with the appropriate order value
    #     )

# from django.contrib import admin
# from .models import Maintainencepoint, Maintenance_List

# class MaintenanceListAdminForm(forms.ModelForm):
#     class Meta:
#         model = Maintenance_List
#         fields = '__all__'

# @admin.register(Maintenance_List)
# class MaintenanceListAdmin(admin.ModelAdmin):
#     form = MaintenanceListAdminForm
#     change_form_template = "admin/custom_template.html"
    
#     class Media:
#         js = ("js/admin_order_swap2.js",) # Register Maintainencepoint model
# admin.site.register(Maintenance_List, MaintenanceListAdmin)  # Register Maintenance_List model
@admin.register(Repairing)
# class RepairingAdmin(admin.ModelAdmin):
#     list_display = ['repairing_id', 'product_id', 'mileage', 'customer_description', 'get_replace_parts_names', 'receiver_description', 'feedback']
#     list_filter = ['product_id', 'mileage']
#     search_fields = ['repairing_id', 'product_id__sku', 'customer_description']
#     ordering = ['-id']

#     def get_replace_parts_names(self, obj):
#         return ", ".join([part.part_name for part in obj.replace_parts.all()])

#     get_replace_parts_names.short_description = 'Replace Parts'
class RepairingAdmin(admin.ModelAdmin):
    list_display = ['repairing_id', 'product_id', 'mileage', 'customer_description', 'receiver_description', 'feedback']
    list_filter = ['product_id__sku','repairing_id']
    # search_fields = ['repairing_id', 'product_id__sku', 'customer_description']
    ordering = ['-id']
    def product_id(self, obj):
        return obj.product.sku
    def get_replace_parts_names(self, obj):
        return ", ".join([part.part_name for part in obj.replace_parts.all()])
    def time_spent_s(self, obj):
        return f"{obj.time}s"

    get_replace_parts_names.short_description = 'Replace Parts'

    # Optionally, override the save_model method to perform custom logic
    def save_model(self, request, obj, form, change):
        # Custom logic to be executed when saving the model instance
        super().save_model(request, obj, form, change)

# class RepairingAdmin(admin.ModelAdmin):
#     list_display = ['repairing_id', 'product_id', 'mileage', 'customer_description', 'get_replace_parts_names', 'receiver_description', 'feedback']
#     list_filter = ['product_id', 'mileage']
#     search_fields = ['repairing_id', 'product_id__sku', 'customer_description']
#     ordering = ['-id']

#     def get_replace_parts_names(self, obj):
#         return ", ".join([part.part_name for part in obj.replace_parts.all()])

#     get_replace_parts_names.short_description = 'Replace Parts'
class WarrantyAdmin(admin.ModelAdmin):
    list_display = ['Warranty_id', 'mileage','product_id', 'cause', 'review', 'remarks','failure_description']
    list_filter = ['product_id__sku']
    search_fields = ['Warranty_id','product_id__sku','failure_description']
    ordering = ['-id']

    def get_replace_parts_names(self, obj):
        return ", ".join([part.part_name for part in obj.replace_parts.all()])

    get_replace_parts_names.short_description = 'Replace Parts'
    # def time_spent_s(self, obj):
    #     return f"{obj.time}s"

    # Optionally, override the save_model method to perform custom logic
    def save_model(self, request, obj, form, change):
        # Custom logic to be executed when saving the model instance
        super().save_model(request, obj, form, change)

@admin.register(newSparePart)
class SparePartAdmin(admin.ModelAdmin):
    list_display = ['id', 'product_sku', 'model_id', 'id_code', 'part_name']
    list_filter = ['product__sku']  # Use product__sku for filtering
    search_fields = ['model_id', 'id_code', 'part_name']

    def product_sku(self, obj):
        return obj.product.sku

    product_sku.short_description = 'Product SKU'
# class VehicleResource(resources.ModelResource):
#     id = fields.Field(attribute='id', column_name='ID')  # Add the id field
#     MODEL_SKU = fields.Field(column_name='MODEL SKU', attribute='MODEL_SKU')

#     CATEGORY = fields.Field(column_name='CATEGORY', attribute='CATEGORY')
#     MODEL_NAME = fields.Field(column_name='MODEL NAME', attribute='MODEL_NAME')
#     FACTORY = fields.Field(column_name='FACTORY', attribute='FACTORY')
#     SERIES = fields.Field(column_name='SERIES', attribute='SERIES')
#     FACTORY_NAME = fields.Field(column_name='FACTORY NAME', attribute='FACTORY_NAME')
#     COLOR = fields.Field(column_name='COLOR', attribute='COLOR')
#     EU_TYPE = fields.Field(column_name='EU TYPE', attribute='EU_TYPE')
#     WHEELS = fields.Field(column_name='WHEELS', attribute='WHEELS')
#     STEERING = fields.Field(column_name='STEERING', attribute='STEERING')
#     SCREEN = fields.Field(column_name='SCREEN', attribute='SCREEN')
#     LIGHTS = fields.Field(column_name='LIGHTS', attribute='LIGHTS')
#     CARGO_COMPARTMENTS = fields.Field(column_name='CARGO COMPARTMENTS', attribute='CARGO_COMPARTMENTS')
#     COMMUNICATION_TERMINAL = fields.Field(column_name='COMMUNICATION TERMINAL', attribute='COMMUNICATION_TERMINAL')
#     vehicle_system_id = fields.Field(column_name='vehicle_system_id', attribute='vehicle_system_id', widget=DecimalWidget())

#     class Meta:
#         model = Vehicle
#         skip_unchanged = True
#         report_skipped = False
#         fields = (
#               'id',
#             'MODEL_SKU', 'CATEGORY', 'MODEL_NAME', 'FACTORY', 'SERIES', 'FACTORY_NAME',
#             'COLOR', 'EU_TYPE', 'WHEELS', 'STEERING', 'SCREEN', 'LIGHTS',
#             'CARGO_COMPARTMENTS', 'COMMUNICATION_TERMINAL', 'vehicle_system_id'
#         )
#     def after_import(self, dataset, result, using_transactions, dry_run, **kwargs):
#         if not dry_run:
#             # Access the imported data from the dataset
#             imported_data = list(dataset.dict)

#             # Display the imported data in the console
#             for row in imported_data:
#                 print(row)
# @admin.register(Vehicle)
# class VehicleAdmin(ImportExportModelAdmin):
#     resource_class = VehicleResource
#     def import_resource(self, request, resource, *args, **kwargs):
#         result = super().import_resource(request, resource, *args, **kwargs)
#         imported_data = resource.get_queryset()

#     # Display the imported data in the console
#         for row in imported_data:
#             print(row)

#         return result
#     list_display = ('id',
#             'MODEL_SKU', 'CATEGORY', 'MODEL_NAME', 'FACTORY', 'SERIES', 'FACTORY_NAME','COLOR', 'EU_TYPE', 'WHEELS', 'STEERING', 'SCREEN', 'LIGHTS',
#             'CARGO_COMPARTMENTS', 'COMMUNICATION_TERMINAL', 'vehicle_system_id')  # Customize the displayed fields
#     list_filter = ('CATEGORY', 'MODEL_SKU', 'COLOR')  # Add filters for the listed fields
#     search_fields = ('MODEL_SKU', 'MODEL_NAME', 'vehicle_system_id')  # Add search fields
# # @admin.register(WarrantyClaim)
# # class WarrantyClaimAdmin(admin.ModelAdmin):
# #     list_display = ['product', 'mileage', 'failure_description', 'repair_parts', 'cause', 'repair_remarks', 'review', 'remark', 'created_at', 'display_image', 'display_video']

# #     def product(self, obj):
# #         return obj.product.sku

# #     product.short_description = 'Product SKU'

# #     def display_image(self, obj):
# #         if obj.image:
# #             return format_html('<img src="{}" height="50" width="50" />', obj.image.url)
# #         else:
# #             return 'No image'

# #     display_image.short_description = 'Image'

# #     def display_video(self, obj):
# #         if obj.video:
# #             return format_html('<a href="{}">Link</a>', obj.video)
# #         else:
# #             return 'No video'

# #     display_video.short_description = 'Video'

# class CategoryAdmin(admin.ModelAdmin):
#     list_display = ('id', 'name', 'description')
#     list_filter = ('name',)



# class ProductAdmin(admin.ModelAdmin):
#     list_display = ('sku', 'vin_code', 'manufacture', 'country', 'series', 'model_name', 'factory_name', 'color', 'eu_type_approval', 'body_type', 'steering_power', 'wheels', 'screen', 'lights', 'cargo_compartments', 'communication_terminal', 'date_of_manufacture', 'orderer', 'orderer_phone', 'orderer_email', 'importer', 'dealer',  'image')
#     # list_filter = ('category', 'sub_category')
#     search_fields = ('sku', 'vin_code', 'model_name', 'factory_name', 'orderer', 'importer', 'dealer')

# # admin.site.register(Product, ProductAdmin)





# class SubcategoryAdmin(admin.ModelAdmin):
#     list_display = ('id', 'name', 'parent')
#     list_filter = ('parent',)
# # class ProductAdmin(admin.ModelAdmin):
#     # list_display = [field.name for field in Product._meta.get_fields()]






# # class ProductServiceAdmin(admin.ModelAdmin):
# #     list_display = ('name', 'product_name', 'is_active', 'comment', 'executed', 'fill', 'value', 'time_spent')

# #     def product_name(self, obj):
# #         return f"{obj.product.model_name} - {obj.product.color}"

# #     def time_spent_s(self, obj):
# #         return f"{obj.time_spent}s"

# #     product_name.admin_order_field = 'product__model_name'
# #     product_name.short_description = 'Product Name'

# class HistoryAdmin(admin.ModelAdmin):
#     exclude = ('timestamp',)
#     list_display = ('historical_note', 'description', 'product_vin_code','timestamp')
#     list_filter = ('historical_note', 'VIN_code__vin_code')
#     search_fields = ('description', 'VIN_code__vin_code')
#     date_hierarchy = 'timestamp'

#     def product_vin_code(self, obj):
#         if obj.VIN_code:
#             return obj.VIN_code.vin_code
#         else:
#             return '-'
#     product_vin_code.short_description = 'Product VIN'

class ServiceImageAdmin(admin.ModelAdmin):
    def image1_tag(self, obj):
        if obj.image1:
            return format_html('<img src="{}" width="50" height="50" />'.format(obj.image1.url))
        else:
            return '-'
    image1_tag.short_description = 'Image 1'

    def image2_tag(self, obj):
        if obj.image2:
            return format_html('<img src="{}" width="50" height="50" />'.format(obj.image2.url))
        else:
            return '-'
    image2_tag.short_description = 'Image 2'

    def image3_tag(self, obj):
        if obj.image3:
            return format_html('<img src="{}" width="50" height="50" />'.format(obj.image3.url))
        else:
            return '-'
    image3_tag.short_description = 'Image 3'

    def image4_tag(self, obj):
        if obj.image4:
            return format_html('<img src="{}" width="50" height="50" />'.format(obj.image4.url))
        else:
            return '-'
    image4_tag.short_description = 'Image 4'

    def product_vin_code(self, obj):
        return obj.product.vin_code


    list_display = ('id', 'product_vin_code', 'image1_tag', 'image2_tag', 'image3_tag', 'image4_tag')
    list_filter = ('product__vin_code',)
    search_fields = ('product__vin_code', 'product__name',)
    # date_hierarchy = 'product__created_at'
# class MaintainencePanelAdmin(admin.ModelAdmin):
#     def display_images(self, obj):
#         images = []
#         if obj.image_1:
#             images.append(format_html('<img src="{}" height="100"/>', obj.image_1.url))
#         if obj.image_2:
#             images.append(format_html('<img src="{}" height="100"/>', obj.image_2.url))
#         if obj.image_3:
#             images.append(format_html('<img src="{}" height="100"/>', obj.image_3.url))
#         if obj.image_4:
#             images.append(format_html('<img src="{}" height="100"/>', obj.image_4.url))
#         return format_html(' '.join(images))

#     display_images.short_description = 'Images'  # Column name in admin list view

#     def display_video_thumbnail(self, obj):
#         if obj.video:
#             # Extract the video ID from the URL
#             video_id = obj.video.split('/')[-1]
#             thumbnail_url = f'https://img.youtube.com/vi/{video_id}/0.jpg'  # Assuming YouTube video
#             video_url = obj.video
#             return format_html('<a href="{}" target="_blank"><img src="{}" height="100"/></a>', video_url, thumbnail_url)
#         return ''

#     display_video_thumbnail.short_description = 'Video Thumbnail'  # Column name in admin list view

#     list_display = ['name', 'instructions', 'instruction_active', 'fill_active', 'value_active', 'display_images', 'display_video_thumbnail']
#     search_fields = ['name', 'instructions']

class ChapterTabularInline(SortableTabularInline):
    model = Maintainencepoint
    exclude = ['instructions','instruction_active','fill_active','value_active','image_1','image_2','image_3','image_4','video','my_order']
    can_delete = False
     

class ServiceAdmin(SortableAdminMixin,admin.ModelAdmin):
    inlines = [ChapterTabularInline]

    class Media:
        js = (
            'admin/js/vendor/jquery/jquery.js',
            'admin/js/jquery.init.js',
            'adminsortable2/js/plugins/admincompat.js',
            'adminsortable2/js/libs/jquery.ui.core-1.11.4.js',
            'adminsortable2/js/libs/jquery.ui.widget-1.11.4.js',
            'adminsortable2/js/libs/jquery.ui.mouse-1.11.4.js',
            'adminsortable2/js/libs/jquery.ui.sortable-1.11.4.js',
            'adminsortable2/js/list-sortable.js',
            'adminsortable2/js/inline-sortable.js',
        )
    list_display = ['my_order', 'Maintenance_list_id', 'Maintenance_list_name', 'display_mileage', 'display_Year', 'display_Factory_name']
    list_filter = ('Factory_name', 'Year', 'mileage')
    ordering = ['my_order']


    serializer_class = addServiceSerializer
    def add_view(self, request, form_url='', extra_context=None):
        extra_context = extra_context or {}
        extra_context['title'] = 'Add New Maintenance list'  # Customize the button text here
        return super().add_view(request, form_url, extra_context)

    def display_image_1(self, obj):
        if obj.image_1:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_1.url))
        else:
            return ''
    display_image_1.short_description = 'Image 1'

    def display_image_2(self, obj):
        if obj.image_2:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_2.url))
        else:
            return ''
    display_image_2.short_description = 'Image 2'

    def display_image_3(self, obj):
        if obj.image_3:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_3.url))
        else:
            return ''
    display_image_3.short_description = 'Image 3'

    def display_image_4(self, obj):
        if obj.image_4:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_4.url))
        else:
            return ''
    display_image_4.short_description = 'Image 4'

    def display_video_thumbnail(self, obj):
        if obj.video:
            # Extract the video ID from the URL
            video_id = obj.video.split('/')[-1]
            thumbnail_url = f'https://img.youtube.com/vi/{video_id}/0.jpg'  # Assuming YouTube video
            video_url = obj.video
            return format_html('<a href="{}" target="_blank"><img src="{}" height="100"/></a>', video_url, thumbnail_url)
        return ''
    # def display_Maintenance_List_Point_name(self, obj):
    #     return ', '.join([str(mp) for mp in obj.Maintenance_List_Point_name__])
    # display_Maintenance_List_Point_name.short_description = 'Maintainencepoint'

    def display_mileage(self, obj):
        return ', '.join([str(m) for m in obj.mileage.all()])
    display_mileage.short_description = 'Mileage'

    def display_Year(self, obj):
        return ', '.join([str(y) for y in obj.Year.all()])
    display_Year.short_description = 'Year'

    def display_Factory_name(self, obj):
        return ', '.join([str(f) for f in obj.Factory_name.all()])
    display_Factory_name.short_description = 'Factory Name'

    def display_SKU(self, obj):
        return ', '.join([str(s) for s in obj.SKU.all()])
    display_SKU.short_description = 'SKU'

# class ProductTotalTimeAdmin(admin.ModelAdmin):
#     list_display = ['id', 'product', 'service', 'total_time_spent']

# admin.site.register(ProductTotalTime, ProductTotalTimeAdmin)







@admin.register(ProductService)
class ProductServiceAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'product_name', 'is_active', 'executed', 'user_name','time_spent_s','fill','value','comment')
    list_filter = ('user', 'product')
    search_fields = ('name', 'comment', 'product__name', 'product__sku', 'user__username')
    ordering = ('-id',)

    def time_spent_s(self, obj):
        return f"{obj.time_spent}s" if obj.time_spent else "0s"
    def user_name(self, obj):
        return obj.user.name

    def product_name(self, obj):
        return obj.product.model_name

    user_name.short_description = 'User'
    product_name.short_description = 'Product'
# class MaintenanceAdmin(admin.ModelAdmin):
#     list_display = ['product_sku', 'mileage', 'customer_description', 'receiver_description', 'feedback', 'replace_part']

#     def product_sku(self, obj):
#         return obj.product_id.sku

#     product_sku.short_description = 'Product SKU'

# admin.site.register(Maintenance, MaintenanceAdmin)





# @admin.register(CheckMaintenance)
# class CheckMaintenanceAdmin(admin.ModelAdmin):
#     list_display = ('product', 'maintenance_name', 'is_active')
#     list_filter = ('is_active',)
#     search_fields = ('product__name', 'maintenance_name')

#     def product(self, obj):
#         return obj.product_id.sku

#     product.short_description = 'Product'
# @admin.register(CheckWarranty)
# class CheckWarrantyAdmin(admin.ModelAdmin):
#     list_display = ('product', 'warranty_name', 'is_active')
#     list_filter = ('is_active',)
#     search_fields = ('product__name', 'warranty_name')

#     def product(self, obj):
#         return obj.product_id.sku

#     product.short_description = 'Product'
# @admin.register(Maintenance)
# class MaintenanceAdmin(admin.ModelAdmin):
#     list_display = ['product_id', 'mileage', 'customer_description', 'get_replace_parts_names', 'receiver_description', 'feedback']
#     list_filter = ['product_id', 'mileage']
#     search_fields = ['product_id__sku', 'customer_description']
#     ordering = ['-id']
#     class Meta:
#         verbose_name = "Repairing"

#     def get_replace_parts_names(self, obj):
#         return ", ".join([part.part_name for part in obj.replace_parts.all()])

#     get_replace_parts_names.short_description = 'Replace Parts'

#     # Optionally, override the save_model method to perform custom logic
#     def save_model(self, request, obj, form, change):
#         # Custom logic to be executed when saving the model instance
#         super().save_model(request, obj, form, change)

class MaintainencepointAdmin(admin.ModelAdmin):
    list_display = ('Point_id','Maintainencepoint_name', 'instruction_active', 'fill_active', 'value_active', 'display_image_1', 'display_image_2', 'display_image_3', 'display_image_4', 'display_video_thumbnail')
    list_filter = ('instruction_active', 'fill_active', 'value_active')
    search_fields = ('point_name',)

    def display_image_1(self, obj):
        if obj.image_1:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_1.url))
        else:
            return ''
    display_image_1.short_description = 'Image 1'

    def display_image_2(self, obj):
        if obj.image_2:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_2.url))
        else:
            return ''
    display_image_2.short_description = 'Image 2'

    def display_image_3(self, obj):
        if obj.image_3:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_3.url))
        else:
            return ''
    display_image_3.short_description = 'Image 3'

    def display_image_4(self, obj):
        if obj.image_4:
            return format_html('<img src="{}" height="50"/>'.format(obj.image_4.url))
        else:
            return ''
    display_image_4.short_description = 'Image 4'

    def display_video_thumbnail(self, obj):
        if obj.video:
            # Extract the video ID from the URL
            video_id = obj.video.split('/')[-1]
            thumbnail_url = f'https://img.youtube.com/vi/{video_id}/0.jpg'  # Assuming YouTube video
            video_url = obj.video
            return format_html('<a href="{}" target="_blank"><img src="{}" height="100"/></a>', video_url, thumbnail_url)
        return ''
    display_video_thumbnail.short_description = 'Video Thumbnail'




# class MaintainencePointAdmin(admin.ModelAdmin):
#     list_display = ('Maintainencepoint_name', 'my_order')
#     list_filter = ('instruction_active', 'fill_active', 'value_active')
#     search_fields = ('Maintainencepoint_name',)
#     ordering = ('my_order',)

# class MaintenanceListAdmin(admin.ModelAdmin):
#     list_display = ( 'open_popup',)

#     def open_popup(self, obj):
#         change_url = reverse('admin:%s_%s_change' % (obj._meta.app_label,  obj._meta.model_name),  args=[obj.pk])
#         return format_html('<a href="javascript:void(0);" onclick="window.open(\'{}\', \'Popup\', \'width=800,height=600\');">Open Popup</a>', change_url)

#     open_popup.short_description = "Open Popup"

# admin.site.register(MyModel, MyModelAdmin)

    

# admin.site.register(Maintainencepoint, MaintainencePointAdmin)
# admin.site.register(Maintenance_List, MaintenanceListAdmin)





# class MaintenanceListPointAdmin(SortableAdminMixin,admin.ModelAdmin):
#     class Media:
#         js = (
#             'admin/js/vendor/jquery/jquery.js',
#             'admin/js/jquery.init.js',
#             'adminsortable2/js/plugins/admincompat.js',
#             'adminsortable2/js/libs/jquery.ui.core-1.11.4.js',
#             'adminsortable2/js/libs/jquery.ui.widget-1.11.4.js',
#             'adminsortable2/js/libs/jquery.ui.mouse-1.11.4.js',
#             'adminsortable2/js/libs/jquery.ui.sortable-1.11.4.js',
#             'adminsortable2/js/list-sortable.js',
#             'adminsortable2/js/inline-sortable.js',
#         )
#     list_display = ['Maintenance_List_Point_name', 'display_maintainencepoint', 'my_order']
#     list_filter = ('Maintenance_List_Point_name', )
#     ordering = ['my_order']


#     serializer_class = MaintenanceListPointSerializer
    

#     def display_maintainencepoint(self, obj):
#         return ', '.join([str(mp) for mp in obj.maintenance_points.all()])
#     display_maintainencepoint.short_description = 'maintenance_points'

    

# admin.site.register(Maintainencepoint, MaintainencepointAdmin)
# admin.site.register(MaintenanceListPoint, MaintenanceListPointAdmin)
admin.site.register(ServiceImage, ServiceImageAdmin)

admin.site.register(Warranty,WarrantyAdmin)
admin.site.site_header = 'CFMOTO'
# admin.site.register(ServiceImage)
# admin.site.register(SparePart)
# admin.site.register(Maintainence_panel, MaintainencePanelAdmin)

# admin.site.register(ProductService, ProductServiceAdmin)
# admin.site.register(Product, ProductAdmin)
# admin.site.register(Subcategory, SubcategoryAdmin)
# admin.site.register(Category, CategoryAdmin)
# admin.site.register(Service, ServiceAdmin)

# admin.site.register(Service, ServiceAdmin)
# admin.site.register(Service, ServiceAdmin)
# admin.site.register(Mileage)

# admin.site.register(Service, ServiceAdmin)
admin.site.register(Mileage)
admin.site.register(Year)
