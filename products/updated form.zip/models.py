from django.db import models
from django.utils import timezone
import random


class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name
class Subcategory(models.Model):
    name = models.CharField(max_length=100)
    parent = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='subcategories')

    def __str__(self):
        return self.name

class Product(models.Model):
    sku = models.CharField(max_length=50, unique=True, editable=False, null=True)
    vin_code = models.CharField(max_length=50, null=True)
    manufacture = models.CharField(max_length=100, null=True)
    country = models.CharField(max_length=100, null=True)
    series = models.CharField(max_length=100, null=True)
    model_name = models.CharField(max_length=100, null=True)
    factory_name = models.CharField(max_length=100, null=True)
    color = models.CharField(max_length=50, null=True)
    eu_type_approval = models.CharField(max_length=50, null=True)
    body_type = models.CharField(max_length=50, null=True)
    steering_power = models.CharField(max_length=50, null=True)
    wheels = models.CharField(max_length=50, null=True)
    screen = models.CharField(max_length=50, null=True)
    lights = models.CharField(max_length=50, null=True)
    cargo_compartments = models.CharField(max_length=50, null=True)
    communication_terminal = models.CharField(max_length=50, null=True)
    date_of_manufacture = models.DateField(null=True)
    orderer = models.CharField(max_length=100, null=True)
    orderer_phone = models.CharField(max_length=50, null=True)
    orderer_email = models.EmailField(null=True)
    importer = models.CharField(max_length=100, null=True)
    dealer = models.CharField(max_length=100, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products', null=True)
    sub_category = models.ForeignKey(Subcategory, on_delete=models.CASCADE, related_name='products', null=True)
    image = models.ImageField(upload_to='product_images/', null=True, blank=True)
    

    def save(self, *args, **kwargs):
        if not self.sku:
            # generate a random 6-digit SKU
            while True:
                sku = ''.join(random.choices('0123456789', k=6))
                if not Product.objects.filter(sku=sku).exists():
                    break
            self.sku = sku
        super().save(*args, **kwargs)

class SparePart(models.Model):
    model_id = models.CharField(max_length=100)
    id_code = models.CharField(max_length=100)
    part_name = models.CharField(max_length=100)
    description = models.TextField()
    def __str__(self):
        return self.part_name
# class History(models.Model):
#     product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='history')
#     timestamp = models.DateTimeField(auto_now_add=True)
#     description = models.CharField(max_length=255)

#     class Meta:
#         ordering = ['-timestamp']
# 333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333

class Service(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class ServiceImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    image1 = models.ImageField(upload_to='service_images/', null=True, blank=True)
    image2 = models.ImageField(upload_to='service_images/', null=True, blank=True)
    image3 = models.ImageField(upload_to='service_images/', null=True, blank=True)
    image4 = models.ImageField(upload_to='service_images/', null=True, blank=True)

    def __str__(self):
        return f"ServiceImage {self.id} for {self.product.name}"





# class SubService(models.Model):
#     service = models.ForeignKey(Service, on_delete=models.CASCADE)
#     is_active = models.BooleanField(default=True)
#     comment = models.TextField(null=True, blank=True)
#     executed = models.BooleanField(default=False)
#     fill = models.CharField(max_length=50, null=True, blank=True)
#     value = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)

#     def __str__(self):
#         return f"{self.service} - {self.fill}"




# 333333333333333333333333333333333333333333333333333333333333333333333
class ProductService(models.Model):
    is_active = models.BooleanField(default=True)
    comment = models.TextField(null=True, blank=True)
    executed = models.BooleanField(default=False)
    fill = models.CharField(max_length=50, null=True, blank=True)
    value = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='services', null=True)
    name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.name} - {self.product.sku}"

class MechanicalNote(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='mechanical_notes')
    note = models.TextField()
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.product} - {self.date_created}"




class History(models.Model):
    timestamp = models.DateTimeField(default=timezone.now)
    description = models.CharField(max_length=200)
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=True)

    def __str__(self):
        return f"{self.timestamp} - {self.description} - Product: {self.product.sku}"