from rest_framework import serializers
from .models import Category,Product,Subcategory,SparePart,Service,ProductService,MechanicalNote,History,ServiceImage
# from simple_history.models import HistoricalRecords


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ('id', 'name', 'description')

class SubcategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Subcategory
        fields = ('id', 'name', 'parent')

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'
class SparePartSerializer(serializers.ModelSerializer):
    class Meta:
        model = SparePart
        fields = ('model_id', 'id_code', 'part_name', 'description')


# class HistorySerializer(serializers.ModelSerializer):
#     class Meta:
#         model = History
#         fields = ['id', 'product', 'timestamp', 'description']
class getProductSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(read_only=True)
    sub_category = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Product
        fields = '__all__'
class addServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = '__all__'
# class ProductServiceSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = ProductService
#         fields = '__all__'
class MechanicalNoteSerializer(serializers.ModelSerializer):
    class Meta:
        model = MechanicalNote
        fields = ('id', 'product', 'note', 'date_created')


class HistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = History
        fields = ('id', 'timestamp', 'description', 'product')



class ServiceImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ServiceImage
        fields = ('product', 'image1', 'image2', 'image3', 'image4')




class ProductServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductService
        fields = '__all__'