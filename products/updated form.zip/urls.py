from django.urls import path
from .views import CategoryListCreateAPIView,create_services,SubcategoryList,create_product,SubcategoryListView,SubcategoryDetailView,SubcategoryByParentView,SubcategoryCreateView,SparePartDetail,SparePartList,get_product_by_vin,add_service,get_services,mechanical_note_create,create_history,get_history_by_product,create_service_image
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('create/category', CategoryListCreateAPIView.as_view(), name='category-list-create'),
    path('subcategories/', SubcategoryListView.as_view(), name='subcategory-list'),
    path('subcategories/<int:pk>/', SubcategoryDetailView.as_view(), name='subcategory-detail'),
    path('categories/<int:parent_id>/subcategories/', SubcategoryByParentView.as_view(), name='subcategory-by-parent'),
    path('products/create/', create_product, name='create_product'),
    path('subcategories/create/', SubcategoryCreateView.as_view(), name='subcategory-create'),
    path('spareparts/', SparePartList.as_view(), name='sparepart_list'),
    path('spareparts/<int:pk>/', SparePartDetail.as_view(), name='sparepart_detail'),
    path('product/vin/<str:vin_code>/', get_product_by_vin, name='get_product_by_vin'),
    path('services/add/',add_service, name='add_service'),
    path('getall/services/', get_services, name='service-list'),
    # path('product-service/create/', product_service_create, name='product-service-create'),
    # path('mechanical_note/create/', mechanical_note_create, name='mechanical_note_create'),
    path('history/create/', create_history, name='create_history'),
    path('products/<int:product_id>/history/',get_history_by_product, name='get_history_by_product'),
    path('service-image/', create_service_image, name='service-image'),
    path('mechanical-notes/create/', mechanical_note_create, name='mechanical_note_create'),
    path('create/product-services/', create_services ,name='create_product'),
    
    

]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)