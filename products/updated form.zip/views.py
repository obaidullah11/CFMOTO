from rest_framework import generics
from .models import Category,Subcategory,Product,SparePart,Service,History,ServiceImage,ProductService
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .serializers import CategorySerializer,SubcategorySerializer,ProductSerializer,SparePartSerializer,getProductSerializer,addServiceSerializer,ProductServiceSerializer,MechanicalNoteSerializer,HistorySerializer,ServiceImageSerializer
from simple_history.models import HistoricalRecords


class CategoryListCreateAPIView(generics.ListCreateAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class SubcategoryList(generics.ListAPIView):
    serializer_class = SubcategorySerializer

    def get_queryset(self):
        category_id = self.kwargs['category_id']
        return Subcategory.objects.filter(parent_id=category_id)

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['category_id'] = self.kwargs['category_id']
        return context


@api_view(['POST'])
def create_product(request):
    serializer = ProductSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




class SubcategoryCreateView(generics.CreateAPIView):
    serializer_class = SubcategorySerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SubcategoryDetailView(generics.RetrieveAPIView):
    queryset = Subcategory.objects.all()
    serializer_class = SubcategorySerializer
class SubcategoryListView(generics.ListAPIView):
    queryset = Subcategory.objects.all()
    serializer_class = SubcategorySerializer
class SubcategoryByParentView(generics.ListAPIView):
    serializer_class = SubcategorySerializer

    def get_queryset(self):
        parent_id = self.kwargs['parent_id']
        return Subcategory.objects.filter(parent__id=parent_id)

# class SparePartSearchView(generics.ListAPIView):
#     serializer_class = SparePartSerializer

#     def get_queryset(self):
#         model_id = self.request.query_params.get('model_id', None)
#         if model_id is not None:
#             queryset = SparePart.objects.filter(model_id=model_id)
#             return queryset
class SparePartList(generics.ListCreateAPIView):
    queryset = SparePart.objects.all()
    serializer_class = SparePartSerializer

class SparePartDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = SparePart.objects.all()
    serializer_class = SparePartSerializer

@api_view(['GET'])
def get_product_by_vin(request, vin_code):
    try:
        product = Product.objects.get(vin_code=vin_code)
        serializer = getProductSerializer(product)
        return Response(serializer.data)    
    except Product.DoesNotExist:
        return Response({'message': 'Product not found'}, status=404)

@api_view(['POST'])
def add_service(request):
    serializer = addServiceSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_services(request):
    services = Service.objects.all()
    serializer = addServiceSerializer(services, many=True)
    return Response(serializer.data)

# @api_view(['POST'])
# def product_service_create(request):
#     data = request.data if isinstance(request.data, list) else [request.data]
#     serializer = ProductServiceSerializer(data=data, many=True)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
#     else:
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
def mechanical_note_create(request):
    serializer = MechanicalNoteSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        message = {'success': 'MechanicalNote created successfully'}
        return Response(data=message, status=status.HTTP_201_CREATED)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        



@api_view(['POST'])
def create_history(request):
    serializer = HistorySerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        message = {'message': 'History instance created successfully.'}
        response_data = {**serializer.data, **message}
        return Response(response_data, status=201)
    return Response(serializer.errors, status=400)

@api_view(['GET'])
def get_history_by_product(request, product_id):
    try:
        history = History.objects.filter(product_id=product_id)
        serializer = HistorySerializer(history, many=True)
        return Response(serializer.data, status=200)
    except History.DoesNotExist:
        message = {'error': f'No history available for product with id {product_id}.'}
        return Response(message, status=404)
# views.py
# @api_view(['GET'])
# def (request, product_id):
#     try:
#         product = Product.objects.get(product=product_id)
#         print("=====>",product)
#         history = product.services.all()
#         print("=====>",history)
#         serializer = HistorySerializer(history, many=True)
#         print("=====>",serializer.data)
#         return Response(serializer.data, status=200)
#     except Product.DoesNotExist:
#         message = {'error': f'Product with id {product_id} does not exist.'}
#         return Response(message, status=404)




@api_view(['POST'])
def create_service_image(request):
    serializer = ServiceImageSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response({"message": "ServiceImage created successfully"}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def create_services(request):
    services_data = request.data.get('services', [])
    created_services = []
    for data in services_data:
        service_serializer = ProductServiceSerializer(data=data)
        if service_serializer.is_valid():
            created_service = service_serializer.save()
            created_services.append(created_service)
    return Response({'services': ProductServiceSerializer(created_services, many=True).data}, status=status.HTTP_201_CREATED)
# class ProductServiceListCreate(generics.ListCreateAPIView):
#     queryset = ProductService.objects.all()
#     serializer_class = ProductServiceSerializer

#     def create(self, request, *args, **kwargs):
#         serializer = self.get_serializer(data=request.data, many=True)
#         serializer.is_valid(raise_exception=True)
#         self.perform_create(serializer)
#         headers = self.get_success_headers(serializer.data)
#         return Response({'message': 'Product services created successfully'}, status=status.HTTP_201_CREATED, headers=headers)

#     def perform_create(self, serializer):
#         instances = serializer.save(commit=False)
#         ProductService.objects.bulk_create(instances)